import React from 'react';
import logo from './logo.svg';
import Home from './container/Home';
import './App.css';

function App() {
  return (
    <div className="">
    <Home />
    </div>
  );
}

export default App;
