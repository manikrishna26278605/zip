import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { Button, FormGroup, FormControl } from "react-bootstrap";

import { connect } from 'react-redux';
import {loginAction} from '../actions';


class Login extends Component {
    constructor(){
        super();
        this.state = { 
            username: '',
            password:'',
            email:''

         }
        this.handlesubmit = this.handlesubmit.bind(this);
    }


    componentDidMount(){
            this.props.loginAction();
    }

    handlesubmit(){
        console.log("hhhh", this.state);
    }
    
    render() { 
        return ( 
            <div className="Login">
            <form onSubmit={()=> this.handleSubmit()}>
            <FormGroup controlId="username" bsSize="large">
                <label>Username</label>
                <FormControl
                  autoFocus
                  type="username"
                  value={this.state.username}
                  onChange={e => this.setState({username: e.target.value})}
                />
              </FormGroup>
              <FormGroup controlId="email" bsSize="large">
                <label>Email</label>
                <FormControl
                  autoFocus
                  type="email"
                  value={this.state.email}
                  onChange={e => this.setState({email: e.target.value})}
                />
              </FormGroup>
              <FormGroup controlId="password" bsSize="large">
                <label>Password</label>
                <FormControl
                  value={this.state.password}
                  onChange={e => this.setState({password: e.target.value})}
                  type="password"
                />
              </FormGroup>
              <Button block bsSize="large"  type="submit">
                Login
              </Button>
            </form>
          </div>
        
             );
    }

}

function mapStateToProps(state) {
    return { state }
  }

  function mapDispatchToProps(dispatch) {
    // return bindActionCreators(
    //     {loginAction }, // do not include dispatch here
    //     dispatch
    //   );
    return {
        loginAction: ()=> dispatch(loginAction())
        } 
  }

 
export default connect( mapStateToProps, mapDispatchToProps )(Login);